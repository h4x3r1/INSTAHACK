# INSTAHACK
InstaHack - Just a simple tool for hacking an instagram accounts
<img src="https://raw.githubusercontent.com/termuxhackers-id/instahack/main/data/user/v1.0.6.png">

### installation
````bash
apt-get update
apt-get upgrade
apt-get install git nano
apt-get install python3
apt-get install python3-pip
git clone https://github.com/termuxhackers-id/instahack
cd instahack
pip install -r requirements.txt
python3 ihack.py
````
### commands
command for Kali Linux, Debian and Termux Android.
````bash
python3 ihack.py
````
### require instagram cookies
get your instagram cookies with cookiedough extension
- [install cookiedough](https://chrome.google.com/webstore/detail/cookiedough)
### change logs
```v1.0.8```
- added new bruteforce methods

### contributes
- code by [@iqbalmh18](https://instagram.com/iqbalmh18)
- obfuscator by [@KangProf](https://github.com/KangProf)
